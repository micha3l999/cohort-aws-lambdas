let constants = {
  // Status of students
  ACTIVE: "ACTIVE",
  DISABLED: "DISABLED",
};

module.exports = constants;
